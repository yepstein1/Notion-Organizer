const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type,Authorization',
  'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
};

const NOTION_API_VERSION = process.env.NOTION_API_VERSION || '2022-06-28';
const ANTHROPIC_MODEL = process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-20250514';

const jsonResponse = (statusCode, body) => ({
  statusCode,
  headers: {
    'Content-Type': 'application/json',
    ...corsHeaders
  },
  body: JSON.stringify(body)
});

const readJsonBody = (event) => {
  if (!event.body) {
    return null;
  }

  try {
    return JSON.parse(event.body);
  } catch (error) {
    return null;
  }
};

const buildPrompt = (scratchpadContent) => `You are organizing learning notes into a structured knowledge base.

Take these scratchpad notes and organize them:

${scratchpadContent}

STEP 1 - Identify the topic and choose organization strategy:
- If it's a well-documented technology (React, Python, AWS, etc.), organize content the way its OFFICIAL DOCUMENTATION does
  - React: Group all hooks together, all components together, etc.
  - Python: Group decorators together, comprehensions together, etc.
  - AWS: Group by service, then by operation type
- If it's an academic subject (Biology, History, Math), organize like a TEXTBOOK would
- If no clear standard exists, use FALLBACK principles: simple→complex, chronological, or categorical grouping

STEP 2 - Group by TYPE, not by purpose:
- WRONG: Separate sections for "State Management", "Side Effects", "Performance" with hooks scattered
- CORRECT: One "Hooks" section containing useState, useEffect, useReducer, useCallback together

Return JSON format:
{
  "organizationMethod": "official-docs" | "textbook" | "fallback",
  "organizationReason": "Brief explanation of why this method was chosen",
  "pages": [
    {
      "topic": "React",
      "tags": ["JavaScript", "Frontend", "Hooks"],
      "sections": [
        {
          "heading": "Hooks",
          "bullets": [
            "useState - manages local component state",
            "useEffect - handles side effects and lifecycle",
            "useReducer - for complex state with multiple sub-values",
            "useCallback - memoizes functions to prevent re-renders"
          ]
        }
      ],
      "relatedTopics": ["JavaScript", "TypeScript"]
    }
  ]
}

If content spans multiple topics, split into separate pages.`;

const parseStructuredPages = (aiText) => {
  const jsonMatch = aiText.match(/\{[\s\S]*\}/);
  const structured = JSON.parse(jsonMatch ? jsonMatch[0] : '{}');

  if (!structured.pages || structured.pages.length === 0) {
    throw new Error('No pages generated from content');
  }

  return {
    pages: structured.pages,
    organizationMethod: structured.organizationMethod || 'unknown',
    organizationReason: structured.organizationReason || ''
  };
};

const buildContentBlocks = (sections) => {
  const blocks = [];

  for (const section of sections) {
    blocks.push({
      object: 'block',
      type: 'heading_2',
      heading_2: {
        rich_text: [{
          type: 'text',
          text: { content: section.heading }
        }]
      }
    });

    for (const bullet of section.bullets) {
      blocks.push({
        object: 'block',
        type: 'bulleted_list_item',
        bulleted_list_item: {
          rich_text: [{
            type: 'text',
            text: { content: bullet }
          }]
        }
      });
    }
  }

  return blocks;
};

const notionFetch = async (path, token, options = {}) => {
  const response = await fetch(`https://api.notion.com/v1/${path}`, {
    ...options,
    headers: {
      'Authorization': `Bearer ${token}`,
      'Notion-Version': NOTION_API_VERSION,
      ...(options.headers || {})
    }
  });

  return response;
};

const findPageByTitle = async (token, databaseId, title) => {
  const response = await notionFetch(`databases/${databaseId}/query`, token, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      filter: {
        property: 'Name',
        title: {
          equals: title
        }
      }
    })
  });

  const data = await response.json();
  return data.results && data.results.length > 0 ? data.results[0] : null;
};

const appendToPage = async (token, pageId, contentBlocks) => {
  const response = await notionFetch(`blocks/${pageId}/children`, token, {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      children: [
        {
          object: 'block',
          type: 'divider',
          divider: {}
        },
        ...contentBlocks
      ]
    })
  });

  if (!response.ok) {
    const errorBody = await response.json();
    throw new Error(`Notion append failed: ${JSON.stringify(errorBody)}`);
  }
};

const createPage = async (token, databaseId, topic, tags, contentBlocks) => {
  const properties = {
    Name: {
      title: [{
        text: { content: topic }
      }]
    }
  };

  // Only add Tags if provided - skip property to avoid type conflicts
  if (tags && tags.length > 0) {
    properties.Tags = {
      rich_text: [{
        text: { content: tags.join(', ') }
      }]
    };
  }

  const response = await notionFetch('pages', token, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      parent: { database_id: databaseId },
      properties,
      children: contentBlocks
    })
  });

  if (!response.ok) {
    const errorBody = await response.json();
    throw new Error(`Notion page creation failed: ${JSON.stringify(errorBody)}`);
  }

  return await response.json();
};

const createOrUpdatePage = async (token, databaseId, pageData) => {
  const contentBlocks = buildContentBlocks(pageData.sections || []);
  const existingPage = await findPageByTitle(token, databaseId, pageData.topic);

  if (existingPage) {
    await appendToPage(token, existingPage.id, contentBlocks);
    return { action: 'updated', topic: pageData.topic, pageId: existingPage.id };
  }

  const newPage = await createPage(token, databaseId, pageData.topic, pageData.tags || [], contentBlocks);
  return { action: 'created', topic: pageData.topic, pageId: newPage.id, pageUrl: newPage.url };
};

const handleHealth = () => jsonResponse(200, { status: 'ok' });

const handleTestConnection = async (event) => {
  const body = readJsonBody(event);
  const databaseId = (body && body.databaseId) || process.env.NOTION_DATABASE_ID;
  const token = process.env.NOTION_TOKEN;

  if (!token) {
    return jsonResponse(500, { error: 'Missing NOTION_TOKEN in environment' });
  }

  if (!databaseId) {
    return jsonResponse(400, { error: 'Missing databaseId' });
  }

  const response = await notionFetch(`databases/${databaseId}`, token, { method: 'GET' });

  if (response.ok) {
    return jsonResponse(200, { ok: true });
  }

  let errorBody = null;
  try {
    errorBody = await response.json();
  } catch (error) {
    errorBody = await response.text();
  }

  return jsonResponse(200, {
    ok: false,
    status: response.status,
    details: errorBody
  });
};

const handleSync = async (event) => {
  const body = readJsonBody(event);
  const token = process.env.NOTION_TOKEN;
  const anthropicKey = process.env.ANTHROPIC_API_KEY;
  const databaseId = (body && body.databaseId) || process.env.NOTION_DATABASE_ID;
  const scratchpadContent = body && body.scratchpadContent;

  if (!token) {
    return jsonResponse(500, { error: 'Missing NOTION_TOKEN in environment' });
  }

  if (!anthropicKey) {
    return jsonResponse(500, { error: 'Missing ANTHROPIC_API_KEY in environment' });
  }

  if (!databaseId) {
    return jsonResponse(400, { error: 'Missing databaseId' });
  }

  if (!scratchpadContent || !scratchpadContent.trim()) {
    return jsonResponse(400, { error: 'Missing scratchpadContent' });
  }

  const aiResponse = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': anthropicKey,
      'anthropic-version': '2023-06-01'
    },
    body: JSON.stringify({
      model: ANTHROPIC_MODEL,
      max_tokens: 2000,
      messages: [{
        role: 'user',
        content: buildPrompt(scratchpadContent)
      }]
    })
  });

  if (!aiResponse.ok) {
    const aiText = await aiResponse.text();
    return jsonResponse(502, { error: 'Anthropic request failed', details: aiText });
  }

  const aiData = await aiResponse.json();
  const aiText = aiData.content && aiData.content.find(block => block.type === 'text')?.text || '';

  let parsed;
  try {
    parsed = parseStructuredPages(aiText);
  } catch (error) {
    return jsonResponse(502, { error: 'Failed to parse AI response' });
  }

  const { pages, organizationMethod, organizationReason } = parsed;
  const results = [];
  const errors = [];
  
  for (const page of pages) {
    try {
      const result = await createOrUpdatePage(token, databaseId, page);
      results.push(result);
    } catch (error) {
      errors.push({ topic: page.topic, error: error.message });
    }
  }

  return jsonResponse(200, { 
    results, 
    pagesCount: results.length, 
    organizationMethod,
    organizationReason,
    errors: errors.length > 0 ? errors : undefined 
  });
};

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 204,
      headers: corsHeaders,
      body: ''
    };
  }

  const path = event.path || '';

  try {
    if (event.httpMethod === 'GET' && path.endsWith('/api/health')) {
      return handleHealth();
    }

    if (event.httpMethod === 'POST' && path.endsWith('/api/notion/test')) {
      return await handleTestConnection(event);
    }

    if (event.httpMethod === 'POST' && path.endsWith('/api/sync')) {
      return await handleSync(event);
    }

    return jsonResponse(404, { error: 'Not found' });
  } catch (error) {
    return jsonResponse(500, { error: 'Unexpected error', details: error.message });
  }
};
